import 'package:cred_sea/core/common/entities/user.dart';

class UserModel extends User{
  UserModel({required super.id, required super.phone, required super.name});

  // factory UserModel.fromJson(Map<String,dynamic> json){
  //
  // }
}