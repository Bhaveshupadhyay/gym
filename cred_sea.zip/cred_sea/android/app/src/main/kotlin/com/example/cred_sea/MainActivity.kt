package com.example.cred_sea

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
