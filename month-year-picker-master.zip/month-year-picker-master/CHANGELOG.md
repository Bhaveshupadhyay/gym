## v0.1.0+1
- Initial release.

## v0.1.0+2
- Added German (de) localisation. ([@Fabian-Balzer](https://github.com/Fabian-Balzer))

## v0.1.0+3
- Added Indonesian (id) localisation. ([@reAlpha39](https://github.com/reAlpha39))

## v0.2.0+1
- **BREAKING CHANGES**: Upgraded to Flutter 3 SDK. ([@laminr](https://github.com/laminr))

## v0.2.0+2
- Added Chinese (zh) localisation. ([@Kingtous](https://github.com/Kingtous))
- Added Chinese (Switzerland) (zh-ch) localisation. ([@Kingtous](https://github.com/Kingtous))
- Added Portuguese (pt) localisation. ([@hugofpsilva](https://github.com/hugofpsilva))
- Added French (fr) localisation. ([@LamsaLL](https://github.com/LamsaLL))
- Added Vietnamese (vi) localisation. ([@trinhvuduc](https://github.com/trinhvuduc))

## v0.2.0+3
- Added Japanese (ja) localisation. ([@kogepan159](https://github.com/kogepan159))

## v0.2.0+4
- Added Thailand (th) localisation. ([@STP-PMT](https://github.com/STP-PMT))
- Added Korean (ko) localisation. ([@hawk0530-mintsoft](https://github.com/hawk0530-mintsoft))
- Added Turkish (tr) localisation. ([@azerturk](https://github.com/azerturk))

## v0.3.0+1
- **BREAKING CHANGES**: Upgraded to Dart 3 and Flutter 3.10 SDK.

## v0.4.0+1
- **BREAKING CHANGES**: Upgraded to Dart 3.4 and Flutter 3.22 SDK.
