fvm flutter gen-l10n `
--arb-dir="lib/src/l10n" `
--template-arb-file="month_year_picker_en.arb" `
--output-localization-file="month_year_picker_localizations.dart" `
--output-class="MonthYearPickerLocalizations" `
--output-dir="lib/src/l10n" `
--no-synthetic-package
